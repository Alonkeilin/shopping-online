const mongoose = require("mongoose");
//const User = require('./models/user');
import { User } from './models/user';

mongoose.connect("mongodb://localhost:27017/UsersDB",
    { useNewUrlParser: true, useUnifiedTopology: true },
    (err, mongoClient) => {
        if (err) {
            console.log(err);
            return;
        }
        console.log("We're connected to " + mongoClient.name + " Database...");
    });




// --------------------------------------


function getAllUsers() {
    return new Promise((resolve, reject) => {
        User.find({}, (err, users) => {
            if (err) {
                reject(err);
                return;
            }
            const userMap  = {};
            setTimeout(()=>{
                 users.forEach(user => userMap[user._id]= user);
                 resolve(userMap); 
                 },0);
        });
    });

}

function loginUser(userName,password){
    return new Promise((resolve, reject) => {
        User.findOne({ email:userName , password:password }, (err, user) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(user);
        });
    });
}


function getUserByUsername(userName) {
    return new Promise((resolve, reject) => {
        User.findOne({ username:userName }, (err, user) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(user);
        });
    });
    
}



// function getAllUsers() {
//     return new Promise((resolve, reject) => {
//         User.find({}).populate("market").exec((err, users) => {
//             if (err) {
//                 reject(err);
//                 return;
//             }
//             resolve(users);
//         });
//     });
// }

function addUser(user) {
    return new Promise((resolve, reject) => {
      
        const userToAdd = new User(user);
        console.log('add user *****');
        console.log(userToAdd);
        userToAdd.save((err, user) => {
            if(err) {
                reject(err);
                return;
            }
            resolve(user)
        });
    });
}

module.exports = { getAllUsers, addUser ,getUserByUsername, loginUser  };

