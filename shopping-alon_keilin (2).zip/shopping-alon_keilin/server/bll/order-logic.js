// get, put, post,delete
// 1. Order should be created.
// 2. Order should be edited.
// 3. Order should be deleted
// 4. Order should be browsed (get)

// ---------Add Order---------

const mongoose = require("mongoose");
import { Order } from './models/order';

mongoose.connect("mongodb://localhost:27017/UsersDB",
    { useNewUrlParser: true, useUnifiedTopology: true }, (err, mongoClient) => {
        if (err) {
            console.log(err);
            return;
        }
        console.log("We're connected to " + mongoClient.name + " database on MongoDB...");
    });

function addOrder(order) {
    return new Promise((resolve, reject) => {
        const order_ = new Order(order);
        order_.save((err, order_) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(order_);
        });
    });
}

//--------Edit Order-----------

function updateOrder(order) {
    return new Promise((resolve, reject) => {
        const order_ = new Order(order);
        Order.updateOne({ _id: order._id }, order_, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(order_);
        });
    });
}

//--------Delete Order-----------

function deleteOrder(order_id) {
    return new Promise((resolve, reject) => {
        Order.deleteOne({ _id:order_id }, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve();
        });
    });
}

// Get One Order

function getOneOrder(_id) {
    return new Promise((resolve, reject) => {
        Order.findById(_id, (err, order) => {
            if (err) return reject(err);
            resolve(order);
        });
    });
}

    function getLastOrder(_clientId){
        return new Promise((resolve, reject) =>{
            Order.findOne({client: _clientId},{}, {sort:{'createdDate':-1}} ,(err, order) =>{
                if(err)  reject(err);
                resolve(order);
            });
        });
    }

module.exports = {
    addOrder,
    deleteOrder,
    updateOrder,
    getOneOrder,
    getLastOrder
}