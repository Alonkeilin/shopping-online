
const mongoose = require ('mongoose');
// Schema and Model for User: 
const userSchema = mongoose.Schema({
    role: String,
    id:{
        type: String,
    },
    email: String,
    password: String,
    city: String,
    street: String,
    firstName: String,
    lastName: String,
    role: String
    
});

export const User = mongoose.model("User", userSchema, "users");

//exports.module = User;
