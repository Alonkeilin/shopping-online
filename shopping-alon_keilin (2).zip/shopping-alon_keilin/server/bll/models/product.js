
const mongoose = require ('mongoose');
// Schema and Model for User: 
const Schema = mongoose.Schema;
const productSchema = mongoose.Schema({
    name: String,
    imgURL: String,
    category: {type:Schema.Types.ObjectId, ref:'Category'},
    price: Number
});
export const Product = mongoose.model("Product", productSchema, "products");
