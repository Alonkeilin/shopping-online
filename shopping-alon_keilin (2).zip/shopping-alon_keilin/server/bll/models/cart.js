
const mongoose = require ('mongoose');
// Schema and Model for User: 
const Schema = mongoose.Schema;
const cartSchema = mongoose.Schema({
    creationDate: {type: Date, default: new Date() },
    client: {type:Schema.Types.ObjectId, ref:'User'} ,
    status:{type: String, default: 'open'}
});
export const Cart = mongoose.model("Cart", cartSchema, "carts");
