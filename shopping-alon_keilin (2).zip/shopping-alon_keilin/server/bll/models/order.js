
const mongoose = require ('mongoose');
// Schema and Model for User: 
const Schema = mongoose.Schema;
const orderSchema = mongoose.Schema({
    cart: {type:Schema.Types.ObjectId, ref:'Cart'},
    client: {type: Schema.Types.ObjectId, ref:'User'},
    finalPrice: Number,
    cityToShip: String ,
    adressToShip: String ,
    dateToShip: Date ,
    createdDate: {type:Date, default: new Date()},
    creditCardNumber: String,
});
export const Order = mongoose.model("Order", orderSchema, "orders");
