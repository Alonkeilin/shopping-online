
const mongoose = require ('mongoose');
// Schema and Model for User: 
const categorySchema = mongoose.Schema({
    name: String
});
export const Category = mongoose.model("Category", categorySchema, "categories");
