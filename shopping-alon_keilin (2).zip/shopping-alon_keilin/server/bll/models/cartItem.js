
const mongoose = require ('mongoose');
import { Product } from './product';

// Schema and Model for User: 
const Schema = mongoose.Schema;
const cartItemSchema = mongoose.Schema({
    amount: Number,
    product: {type:Schema.Types.ObjectId, ref:'Product'},
  //  price:  {type:Schema.Types.ObjectId, ref:'Product'},
    cart: {type:Schema.Types.ObjectId, ref:'cart'} ,
    generalPrice :{
        type:Number
    }
});
cartItemSchema.pre(['save'], function(next){
  Product.findOne({ _id:this.product }, (err, productItem) => {
    this.generalPrice = productItem.price * this.amount;
    next();
});
});

cartItemSchema.pre(['findOneAndUpdate'], function(next){
  
  const updated = this.getUpdate();
  const data = this.getFilter();
  Product.findOne({ _id:data.product }, (err, productItem) => {
    this.update({}, { generalPrice:  productItem.price * updated.amount });
    next();
});
});

export const CartItem = mongoose.model("CartItem", cartItemSchema, "cartItems");
