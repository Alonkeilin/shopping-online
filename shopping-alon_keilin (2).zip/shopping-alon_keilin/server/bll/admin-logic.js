// get, put, post
// 1. admin should add categories.
// 2. admin should edit categories.
// 3. admin should add products
// 4. admin should edit products


// function addCatagory(catagory) {
//     return new Promise((resolve, reject) => {

//         const catagoryToAdd = new Catagory(catagory);
//         catagoryToAdd.save((err, catagory) => {
//             if (err) {
//                 reject(err);
//                 return;
//             }
//             resolve(catagory)
//         });
//     });
// }




const mongoose = require("mongoose");
import { Category } from './models/category';
import { Product } from './models/product';

// Connect to the database: 
mongoose.connect("mongodb://localhost:27017/UsersDB",
    { useNewUrlParser: true, useUnifiedTopology: true }, (err, mongoClient) => {
        if (err) {
            console.log(err);
            return;
        }
        console.log("We're connected to " + mongoClient.name + " database on MongoDB...");
    });

// Create a schema for a category: 
const categorySchema = mongoose.Schema({
    name: String,
    price: Number,
    stock: Number
}, { versionKey: false });

const category = mongoose.model("category", categorySchema, "categories"); // Model, Schema, Collection

//--------------- categories-----------------//

function getAllCategories() {
    return new Promise((resolve, reject) => {
        Category.find({}, (err, categories) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(categories);
           
        });
    });
}

function getOneCategory(_id) {
    return new Promise((resolve, reject) => {
        Category.findById(_id, (err, category) => {
            if (err) return reject(err);
            resolve(category);
        });
    });
}


function addCategory(category) {
    return new Promise((resolve, reject) => {
        const categ = new Category(category);
        categ.save((err, categ) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(categ);
        });
    });
}

function updateCategory(category) {
    return new Promise((resolve, reject) => {
        const categ = new Category(category);
        Category.updateOne({ _id: category._id }, categ, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(categ);
        });
    });
}

//--------------- products-----------------//
function getAllProducts() {
    return new Promise((resolve, reject) => {
        Product.find({}, (err, products) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(products);
        });
    });
}

function getOneProduct(_id) {
    return new Promise((resolve, reject) => {
        Product.findById(_id, (err, product) => {
            if (err) return reject(err);
            resolve(product);
        });
    });
}

function getProductsByCategory(catId){
    return new Promise((resolve, reject) => {
        Product.find({category: catId}, (err, products) => {
            if (err) return reject(err);
            resolve(products);
        });
    });
}


function addProduct(product) {
    return new Promise((resolve, reject) => {
        const prod = new Product(product);
        prod.save((err, prod) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(prod);
        });
    });
}

function updateProduct(product) {
    return new Promise((resolve, reject) => {
        const prod = new Product(product);
        Product.updateOne({ _id: product._id }, prod, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(prod);
        });
    });
}


module.exports = {
    getAllCategories,
    getOneCategory,
    addCategory,
    updateCategory,
    getAllProducts,
    getOneProduct,
    addProduct,
    updateProduct,
    getProductsByCategory
};