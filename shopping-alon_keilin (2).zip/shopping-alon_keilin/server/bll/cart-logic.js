// 1.Client should create a cart
// 2.Client should add Cart Item -with params : cart id
// 3.Client should delete Cart Item by id.
// 4.Client should edit Cart Item by id. 
// 5.Client should get all Cart Items by user id -- how ? 
//          Get Cart by user id , you will have the cart id
//          Get all Cart Items by cart id.
// 6.Client should get all open carts- if a cart doesnt have an order yet , its open.


//Add Cart
import { Cart } from './models/cart';
import { CartItem } from './models/cartItem';
import { Product } from './models/product';


function addCart(cart) {
    return new Promise((resolve, reject) => {
        const _cart = new Cart(cart);
        _cart.save((err, _cart) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(_cart);
        });
    });
}

//Add Cart Item

function addCartItem(cartItem) {
    return new Promise((resolve, reject) => {
        const cartItem_ = new CartItem(cartItem);
        cartItem_.save((err, cartItem_) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(cartItem_);
        });
    });
}
function getCartItems(cartId){
    return new Promise((resolve, reject) => {
        CartItem.find({cart:cartId}).populate('product').exec(function(err, cartItems) {
            if (err) throw err;
            const cartItemsArr = [];
            cartItems.forEach(function(item) {
                const currentItem ={
                    id: item._id,
                    productName:item.product.name,
                    productId: item.product._id,
                    image:item.product.imgURL,
                    amount:item.amount,
                    price:item.generalPrice
                }
              cartItemsArr.push(currentItem);
            });
        
            resolve(cartItemsArr); 
        });
    });
}

// Delete Cart Item

function deleteCartItem(cartItem_id,cartId) {
    return new Promise((resolve, reject) => {
        CartItem.deleteOne({ _id:cartItem_id }, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            CartItem.find({cart:cartId},(err1, cartitems) => {
                resolve(cartitems);
            })
            
        });
    });
}

// Edit Cart Item

function updateCartItem(id,cartItem) {
    return new Promise((resolve, reject) => {
        CartItem.findOneAndUpdate({ _id:id,product:cartItem.productId },{amount:cartItem.amount},{ "new": true}, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(info);
        });
    });
}

// Get Cart by user ID

function getOneCart(_id) {
    return new Promise((resolve, reject) => {
        Cart.findById(_id, (err, cart) => {
            if (err) return reject(err);
            resolve(cart);
        });
    });
}
function getFinalPriceCart(cartId){
    return new Promise((resolve, reject) =>{
        let totalPrice=0;
        CartItem.find({cart: cartId}, (err, cartitem) =>{
            cartitem.forEach((item)=>{
                totalPrice+=parseFloat(item.generalPrice);
            });
            if(err) reject(err)
            resolve(totalPrice);
        })
    })

}
function getOpenCart(userId){
    return new Promise((resolve, reject) =>{
        Cart.findOne({status:'open',client:userId }, (err, cart) =>{
            if(err)  reject(err);
            resolve(cart);
        });
    });
}
function setCartClose(_id) {
    return new Promise((resolve, reject) => {
        Cart.updateOne({ _id:id },{status:'closed'}, (err, info) => {
            if (err) {
                reject(err);
                return;
            }
            resolve(info);
        });
    });
}

module.exports = {
    addCart,
    addCartItem,
    getCartItems,
    deleteCartItem,
    updateCartItem,
    getOneCart,
    getOpenCart,
    getFinalPriceCart,
    setCartClose
}