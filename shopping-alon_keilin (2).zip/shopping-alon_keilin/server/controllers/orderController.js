const express = require("express");

import * as orderLogic from "../bll/order-logic";

const router = express.Router();

// -----Add Order------

router.post("/order/", async (request, response) => {
    try {
        const order = request.body;
        const addedOrder = await orderLogic.addOrder(order);
        response.status(201).json(addedOrder);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// Edit Order

router.put("/order/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const data = request.body;
      
        const updatedOrder = await orderLogic.updateOrder(_id,data);
        response.json(updatedOrder);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// ------Delete Order------------

router.delete("/order/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        await orderLogic.deleteOrder(_id);
        response.sendStatus(204);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// Get Order By ID

router.get("/order/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const order = await orderLogic.getOneOrder(_id);
        response.json(order);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});


router.get("/lastOrder/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const order = await orderLogic.getLastOrder(_id);
        response.json(order);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});


module.exports = router;