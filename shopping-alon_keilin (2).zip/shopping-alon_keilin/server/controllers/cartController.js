const express = require("express");

import * as cartLogic from "../bll/cart-logic";
import { response } from "express";

const router = express.Router();

// Add Cart

router.post("/cart/", async (request, response) => {
    try {
        const cart = request.body.payload;
        const addedCart = await cartLogic.addCart(cart);
        response.status(201).json(addedCart);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

router.get("/cartItem/:_cartId", async(request,response) =>{
    try{

        const cartId = request.params._cartId;
        const cartItems = await cartLogic.getCartItems(cartId);
        response.status(201).json(cartItems);

    }
    catch (err) {
        response.status(500).send(err.message);
    }
})
// Add Cart Item

router.post("/cartItem/", async (request, response) => {
    try {
        const cartItem = request.body.payload;
        const addedCartItem = await cartLogic.addCartItem(cartItem);
        response.status(201).json(addedCartItem);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// Delete Cart Item

router.delete("/cartItem/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const cartId= request.query.cartId;
        const cartitems = await cartLogic.deleteCartItem(_id,cartId);
        
        response.status(201).json(cartitems);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// Edit Cart Item

router.put("/cartItem/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const data = request.body.payload;
      
        const updatedCartItem = await cartLogic.updateCartItem(_id,data);
        response.json(updatedCartItem);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// Get Cart By ID

router.get("/cart/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const cart = await cartLogic.getOneCart(_id);
        response.json(cart);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

router.get('/cart/open/:_userid', async (request, response) => {
    try {
        const userId = request.params._userid;
        const cart = await cartLogic.getOpenCart(userId);
        response.json(cart);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
})

router.get('/cart/finalPrice/:_cartId', async (request, response) => {
    try {
        const cartId = request.params._cartId
        const cart = await cartLogic.getFinalPriceCart(cartId);
        response.json(cart);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
})

router.get('/cart/close/:_id' , async (request, response) =>{ 
    try {
        const _id = request.params._id;
        const cart = await cartLogic.setCartClose(_id);
        response.json(cart);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
})
module.exports = router;