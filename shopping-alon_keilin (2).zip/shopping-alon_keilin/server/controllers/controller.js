const express = require("express");
const logic = require("../bll/user-logic");
const jwt = require("jsonwebtoken");

import * as adminLogic from "../bll/admin-logic";

const router = express.Router();


router.get("/users", async (request, response) => {
    try {
        const users = await logic.getAllUsers();
        response.json(users);
    }
    catch(err) {
        response.status(500).send(err.message);
    }
});



router.post("/token",  async (request, response) => {
   
    const user = request.body.username;
    const password = request.body.password;
    console.log(request.body);
    const loggedInUser =await logic.loginUser(user,password);

     if(loggedInUser){
        const token = jwt.sign({username:loggedInUser.username,email:loggedInUser.email},request.app.get('TokenSecret'),{
            expiresIn:'20m',
            algorithm:'HS256'
        });
        response.json({'token':token , 'user': loggedInUser});
     } else{
         response.status(401).send('User not exists');
     }
    //response.send('lala');

});
router.post("/users", async (request, response) => {
    try {
        const user = request.body;       
        const addedUser = await logic.addUser(user);
        console.log(user);
        response.status(201).json({
            addedUser
        });
    }
    catch(err) {
        response.status(500).send(err.message);
    }
});

// First , go through the screens and try to build logics by the screens.

// Admin controller

// GET All Products
router.get("/products", async (request, response) => {
    try {
        const products = await adminLogic.getAllProducts();
        response.json(products);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// GET One Products
router.get("/product/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const product = await adminLogic.getOneProduct(_id);
        response.json(product);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});


// POST Product 
router.post("/product/", async (request, response) => {
    try {
        const product = request.body;
        const addedProduct = await adminLogic.addProduct(product);
        response.status(201).json(addedProduct);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// PUT Product
router.put("/product/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const product = request.body;
        product._id = _id;
        const updatedProduct = await adminLogic.updateProduct(product);
        response.json(updatedProduct);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// GET All Categories
router.get("/category", async (request, response) => {
    try {
        const categories = await adminLogic.getAllCategories();
        response.json(categories);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

router.get("/product/byCategory/:_catId", async (request, response) => {
    try {
        const _id = request.params._catId;
        const products = await adminLogic.getProductsByCategory(_id);
        response.json(products);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// GET One category
router.get("/category/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const category = await adminLogic.getOneCategory(_id);
        response.json(category);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// POST Category
router.post("/category", async (request, response) => {
    try {
        const category = request.body;
        const addedCategory = await adminLogic.addCategory(category);
        response.status(201).json(addedCategory);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

// PUT category
router.put("/category/:_id", async (request, response) => {
    try {
        const _id = request.params._id;
        const category = request.body;
        category._id = _id;
        const updatedCategory = await adminLogic.updateCategory(category);
        response.json(updatedCategory);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});


module.exports = router;