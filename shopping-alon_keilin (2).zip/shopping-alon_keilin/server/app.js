const express = require("express");
const cors = require("cors");
const session = require("express-session");

const controller = require("./controllers/controller");
const cartController = require("./controllers/cartController");
const orderController = require("./controllers/orderController");
// const bodyParser = require('body-parser');
const server = express();

server.use(cors());
//server.use(bodyParser.json())
server.use(express.json());
server.set('TokenSecret','super');
server.use("/api", controller);
server.use("/api", cartController);
server.use("/api", orderController);
server.use('/', express.static(__dirname + '/public'));

server.listen(3000, () => console.log("Listening on http://localhost:3000"));

