const jwt = require('jsonwebtoken');
import { getUserByUsername } from '../bll/user-logic';
module.exports = (req, res , next) => {
    const token = (req.body && req.body.access_token) || (req.query && req.query.access_token);
    if(token){
        try {
            jwt.verify(token , req.app.get('TokenSecret') ,(err, decoded) =>{
                if(err){
                    return next();
                }
                if(decoded.userName){
                    getUserByUsername(decoded.userName).then((res,err) => {
                        if(res){
                           req.user = res;
                           next();
                        } else{
                            res.status(401).send('Unauthorized');
                        }
                    });
                }
            });
        } catch(err) {
            res.status(401).send(err);
        }
    } else{
        res.status(401).send('Unauthorized');
    }
}
