import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { ProductComponent } from './components/product/product.component';
import { ShopComponent } from './shop/shop.component';
import { SmartOrderComponent } from './smart-order/smart-order.component';

const routes: Routes = [{
  path: 'admin',
  component: AdminComponent,
  data: { title: 'Admin' },
},
{
  path: 'shop',
component: ShopComponent,
data: { title: 'Shop' },
},
{
path: 'order',
component: SmartOrderComponent,
data: { title: 'Checkout' }}];

@NgModule({
  
  imports: [RouterModule.forRoot(routes,{onSameUrlNavigation: 'reload', useHash: false })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
