export interface cartItem{
    id: string,
    productName: string,
    productId: string,
    price: number,
    amount: number,
    image: string
}