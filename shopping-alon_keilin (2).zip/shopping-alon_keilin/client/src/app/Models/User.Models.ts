export interface Registration
{
    Id:number;
    Password:string;
    Email:string;
    City:string;
    Street:string;
    FirstName:string;
    LastName:string;
}