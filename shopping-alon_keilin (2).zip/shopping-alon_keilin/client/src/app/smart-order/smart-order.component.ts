import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../Services/authentication.service';
import { SharedService } from '../Services/shared.service';
import { cartItem } from '../Models/cart-item';

@Component({
  selector: 'app-smart-order',
  templateUrl: './smart-order.component.html',
  styleUrls: ['./smart-order.component.scss']
})
export class SmartOrderComponent implements OnInit {

  currentUser: any = null;
  shoppingCart: any = null;
  cartItems: Array<cartItem> = [];
  totalPrice: number = 0;
  constructor( private sharedService: SharedService,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.currentUser = this.authenticationService.getUser();
    this.getOpenCart();
  }
  doOrder($order){
    console.log($order);
  }
  getOpenCart(){
    this.sharedService.getOpenCart(this.currentUser._id).subscribe((res)=>{
      this.shoppingCart = res;
      this.sharedService.getTotalPriceCart(this.shoppingCart._id).subscribe((res1)=>{
        this.totalPrice = res1;
      });
      this.sharedService.getAllCartItemsByCartID(this.shoppingCart._id).subscribe((res2)=>{
        this.cartItems = res2;
      })
    });
  }

}
