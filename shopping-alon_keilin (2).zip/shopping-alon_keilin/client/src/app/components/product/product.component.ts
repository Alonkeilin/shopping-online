import { Component, OnInit, Input , Output , EventEmitter } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {

  @Input() products : any[] = [];
  @Output() doAction = new EventEmitter();
  baseAssetsUrl =`http://localhost:3000/assets/images/`;
  constructor() { }

  ngOnInit() {
    console.log(this.products)
  }
  selectProduct($product){
    this.doAction.emit($product);
    
}
}
