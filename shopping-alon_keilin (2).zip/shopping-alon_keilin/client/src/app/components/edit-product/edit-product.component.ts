import { Component, OnInit,Input,OnChanges, Output , EventEmitter} from '@angular/core';
import { ProductModel } from './product';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.scss']
})
export class EditProductComponent implements OnInit,OnChanges {

  constructor() { }
    @Input() product: any = null;
    @Input() categories: any[];
    @Output() doAction = new EventEmitter();
    model: ProductModel;
    isEditMode: boolean = false;

   
  ngOnInit() {
    if(this.product){
      this.isEditMode = true;
       this.model =  new ProductModel(this.product._id,this.product.name,
      this.product.price,
      this.product.imgURL,
      this.product.category);
    } else{
      this.model = new ProductModel('','' , 0 ,'','');
    }
   
  }
  ngOnChanges(){
  if(this.product){
    this.model =  new ProductModel(this.product._id,this.product.name,
      this.product.price,
      this.product.imgURL,
      this.product.category);
  }
   
    console.log(this.model)
  }
  onSubmit($product){
    this.doAction.emit($product);
     
  }
  

}
