export class ProductModel{
    constructor(public Id: string, public name: string, public price:Number,
         public imgURL: string
         , public category: string){}
}