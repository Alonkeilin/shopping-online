import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  orderForm: FormGroup;
  @Input() userDetails: any = null;
  @Output() onOrder =  new EventEmitter();
  constructor( private fb: FormBuilder) {
    
   }

   doOrder(){
      this.onOrder.emit(this.orderForm.value);
   }
  ngOnInit() {
    console.log(this.userDetails);
    this.orderForm = this.fb.group({
      city:[this.userDetails.city,Validators.required],
      street:[this.userDetails.street,Validators.required],
      shippingDate:['',Validators.required],
      creditCart:['' ,Validators.required]
      

    });
  }

  
}
