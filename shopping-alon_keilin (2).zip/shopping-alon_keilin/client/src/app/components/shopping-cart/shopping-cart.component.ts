import { Component, OnInit,Input ,Output,EventEmitter } from '@angular/core';
import { cartItem } from '../../Models/cart-item';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.scss']
})
export class ShoppingCartComponent implements OnInit {

  constructor() { }
  baseAssetsUrl:string = environment.baseAssetsUrl;
  @Input() cartItems: cartItem[];
  @Input() totalPrice: number;
  @Input() type: string ='';
  @Output() onDelete = new EventEmitter();
  @Output() onOrder = new EventEmitter();

  ngOnInit() {
  }
  deleteCartItem($cartItemId){
    this.onDelete.emit($cartItemId);
  }
  doOrder(){
    this.onOrder.emit();
  }

}
