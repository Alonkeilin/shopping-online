import { Component, OnInit, Input , Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-category-filter',
  templateUrl: './category-filter.component.html',
  styleUrls: ['./category-filter.component.scss']
})
export class CategoryFilterComponent implements OnInit {

  @Input() categories: Array<any> = [];
  @Output() doAction = new EventEmitter();
  constructor() { }

  ngOnInit() {  
    console.log(this.categories);
  }
  getProductsofCat(catID){
      this.doAction.emit(catID);
  }

}
