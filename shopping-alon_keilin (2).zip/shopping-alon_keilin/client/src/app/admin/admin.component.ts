import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { SharedService } from '../Services/shared.service';
import { ProductModel } from '../components/edit-product/product';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  constructor(private sharedService: SharedService,
    private cd: ChangeDetectorRef) { }

  categories:Array<any> = [];
  products:Array<any> = [];
  productModel:ProductModel = null;
  selectedProduct: any;
  newProduct: boolean = false;
    ngOnInit() {
    this.sharedService.getAllCategories().subscribe((res)=>{
      this.categories = res;
    
    });
    this.getAllProducts();
  }
  getProducts(catId){
    this.sharedService.getProductsByCategory(catId).subscribe((res) =>{
        this.products = res;
        console.log(res);
    })
    console.log(catId);
  }
  getAllProducts(){
    this.sharedService.getAllProducts().subscribe((res) =>{
        this.products = res;
        console.log(res);
    })
    console.log(this.products);
  }
  selectProduct($product){
    console.log($product);
    this.selectedProduct = $product;
    this.newProduct = false;
  }
  addNewProduct(){
    this.newProduct = true;
    this.selectedProduct = null;
  }
  saveNewProduct(productModel){
    this.sharedService.addNewProduct(productModel).subscribe((res) =>{
     // this.getAllProducts();
      this.cd.detectChanges();
    });
  }
 
  updateProduct(productModel){
    this.sharedService.updateProduct(productModel).subscribe((res)=>{
     // productModel = res;
     this.getAllProducts();
     this.cd.detectChanges();
    })
   }
}