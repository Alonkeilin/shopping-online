import { BrowserModule } from '../../node_modules/@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'
import { HttpClient,HttpClientModule } from '@angular/common/http';
import {FormsModule,ReactiveFormsModule,Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { AdminComponent } from './admin/admin.component';
import { ProductComponent } from './components/product/product.component';
import { CategoryFilterComponent } from './components/category-filter/category-filter.component';
import { EditProductComponent } from './components/edit-product/edit-product.component';
import { ShopComponent } from './shop/shop.component';
import { OrderComponent } from './components/order/order.component';
import { SmartOrderComponent } from './smart-order/smart-order.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavbarComponent,
    ShoppingCartComponent,
    AdminComponent,
    ProductComponent,
    CategoryFilterComponent,
    EditProductComponent,
    ShopComponent,
    OrderComponent,
    SmartOrderComponent,
   
  ],
  imports: [
    BrowserModule,NgbModule,FormsModule,ReactiveFormsModule,HttpClientModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }