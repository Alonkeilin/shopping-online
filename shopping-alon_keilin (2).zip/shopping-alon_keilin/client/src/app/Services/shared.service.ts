import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { ProductModel } from '../components/edit-product/product';



@Injectable({
  providedIn: 'root'
})
export class SharedService {

  private currentCartCount = new BehaviorSubject(0);
  currentMessage = this.currentCartCount.asObservable();
  private _apiUrl = 'http://localhost:3000/api'

  constructor(private http: HttpClient) {
   }
   updateCartCount(count: number) {
    this.currentCartCount.next(count)
  }
  getAllCategories(){
    return this.http.get<any[]>(`${this._apiUrl}/category`);
  }
  getProductsByCategory(catID){
    return this.http.get<any[]>(`${this._apiUrl}/product/byCategory/${catID}`);
  }
  getAllProducts(){
    return this.http.get<any[]>(`${this._apiUrl}/products`)
  }
  updateProduct(product: ProductModel): Observable<ProductModel> {
    return this.http.put<ProductModel>(`${this._apiUrl}/product/${product.Id}`, product);
  }
  addNewProduct(product: ProductModel): Observable<ProductModel> {
    return this.http.post<ProductModel>(`${this._apiUrl}/product`, product);
  }
  getOpenCart(userId: string): Observable<any> {
      return this.http.get<any>(`${this._apiUrl}/cart/open/${userId}`);
  }
  getTotalPriceCart(cartId: string): Observable<number> {
    return this.http.get<number>(`${this._apiUrl}/cart/finalPrice/${cartId}`);
  }
  setNewShoppingCart(cart: any):  Observable<any> {
    return this.http.post<any>(`${this._apiUrl}/cart`,cart);
  }
  closeShoppingCart(cartId: string){
    return this.http.get<any>(`${this._apiUrl}/cart/close/${cartId}`);
  }
  getLastOrderByClientID(clientId: string){
    return this.http.get<any>(`${this._apiUrl}/lastOrder/${clientId}`);
  }
  setNewCartItem(cartItemDetails: any){
    return this.http.post<any>(`${this._apiUrl}/cartItem`, cartItemDetails);
  }
  updateCartItem(cartItemDetails: any){
    console.log(cartItemDetails);
    return this.http.put<any>(`${this._apiUrl}/cartItem/${cartItemDetails.id}`,{payload:cartItemDetails});
  }
  deleteCartItem(cartItemId: string,cartId: string){
    return this.http.delete<any>(`${this._apiUrl}/cartItem/${cartItemId}?cartId=${cartId}`);
  }
  getAllCartItemsByCartID(cartId: string){
    return this.http.get<any>(`${this._apiUrl}/cartItem/${cartId}`);
  }
}