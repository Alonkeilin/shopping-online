import { Component, OnInit,AfterViewInit, TemplateRef, ViewChild, Output } from '@angular/core';
import { FormBuilder, FormGroup, Form } from '@angular/forms';
import { Router } from '@angular/router';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { SharedService } from '../Services/shared.service';
import { AuthenticationService } from '../Services/authentication.service';
import { cartItem } from '../Models/cart-item';


@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.scss']
})
export class ShopComponent implements OnInit,AfterViewInit {

  @ViewChild('shoppingMessage' ,{static: false }) shoppingMessage: TemplateRef<any>;
  @ViewChild('amountModal' ,{static: false }) amountModal: TemplateRef<any>;

  categories:Array<any> = [];
  products:Array<any> = [];
  shoppingCart: any = null;
  selectedProduct: any;
  userMessage: string ='';
  buttonTitle: string = '';
  currentUser: any = null;
  isNewClient: boolean;
  amountForm: FormGroup;
  cartItems: Array<cartItem> = [];
  totalPrice: number = 0;
  

  constructor(
    private sharedService: SharedService,
    private authenticationService: AuthenticationService,
    private ngbModalService: NgbModal,
    private fb: FormBuilder,
    private router: Router
    
    

    ) { }
    
    
  ngOnInit() {
    this.sharedService.getAllCategories().subscribe((res)=>{
      this.categories = res;
    
    });
    this.getAllProducts();
    this.currentUser = this.authenticationService.getUser();
    this.getOpenCartAndOrder();
    this.amountForm = this.fb.group({
      amount:['']
    });
    
  }
  ngAfterViewInit(){
    this.ngbModalService.open(this.shoppingMessage, {size: 'lg'});
  }
  
  openAmountModal($product){
    console.log($product);
    this.selectedProduct = $product;
    this.ngbModalService.open(this.amountModal, {size: 'sm'});
  }

  getOpenCartAndOrder(){
    
    let totalPrice:number = 0 ;
    this.sharedService.getOpenCart(this.currentUser._id).subscribe((res)=>{
      this.shoppingCart = res;
      if(!this.shoppingCart){
        this.isNewClient = true;
        this.addNewShoppingCart();
       this.sharedService.getLastOrderByClientID(this.currentUser._id).subscribe((res) =>{
          if(res){
            this.userMessage = `Welcome Back! , your last order was on ${res.createdDate}`;
          } else{
            this.userMessage = 'Welcome to our shop!';
          }
       })
        this.buttonTitle = 'Start Shopping'; 
      } else{
        this.isNewClient = false;
        this.sharedService.getTotalPriceCart(this.shoppingCart._id).subscribe((res1)=>{
          this.totalPrice = res1;
          this.userMessage = `You have an open shopping cart from ${this.shoppingCart.creationDate} with 
          total price of ${this.totalPrice} $`; 
        });
        this.sharedService.getAllCartItemsByCartID(this.shoppingCart._id).subscribe((res2)=>{
          this.cartItems = res2;
        })

        this.buttonTitle = 'Continue Shopping';
      }
     
    });
  }

  updateTotalPriceCart(){
    this.sharedService.getTotalPriceCart(this.shoppingCart._id).subscribe((cartPrice)=>{
      this.totalPrice = cartPrice;
    });
  }

  deleteCartItem($cartItemId){
  
    this.sharedService.deleteCartItem($cartItemId,this.shoppingCart._id).subscribe((res)=>{
    
      if(res.length>0){
        this.cartItems = this.cartItems.filter((newCartItem)=>newCartItem.id !== $cartItemId);
      } else{
        this.cartItems.length=0;
      }
       
      this.updateTotalPriceCart();
      alert('Cart item is deleted');
    })
  }
  orderShoppingCart(){
    this.router.navigate(['order']);
  }
  closeMessage(){
    this.ngbModalService.dismissAll();
  }
  closeAmountModal(){
    const productId = this.selectedProduct._id;
    const amount = this.amountForm.get('amount').value 
    console.log(this.shoppingCart);
    const data = {amount:amount,product:productId,cart:this.shoppingCart._id};
    const existingCartItem = this.cartItems.find((item)=>item.productId === productId);
    if(existingCartItem){
      existingCartItem.amount = amount;
      this.sharedService.updateCartItem(existingCartItem).subscribe((res)=>{
        this.cartItems = this.cartItems.map((item)=>{
          if(item.id === res._id){
            item.price=res.generalPrice,
            item.amount = res.amount
          }
          return item;
        })
        this.updateTotalPriceCart(); 
        this.closeMessage();
      })
    } else{
    this.sharedService.setNewCartItem({payload:data}).subscribe((res) =>{
        const addedCartItem: cartItem = {
          id: res._id,
          productName:this.selectedProduct.name,
          productId:this.selectedProduct._id,
          amount:amount,
          price:res.generalPrice,
          image:this.selectedProduct.imgURL
          
        } 
        this.cartItems.push(addedCartItem);
        this.updateTotalPriceCart(); 
        this.closeMessage();
    })
  }
 
  }
  addNewShoppingCart(){
     this.sharedService.setNewShoppingCart({client:this.currentUser._id,status:'open'}).subscribe((res)=>{
      this.shoppingCart = res;
    })
  }
  getProducts(catId){
    this.sharedService.getProductsByCategory(catId).subscribe((res) =>{
        this.products = res;
    })
  }
  getAllProducts(){
    this.sharedService.getAllProducts().subscribe((res) =>{
        this.products = res;
        console.log(res);
    })
    console.log(this.products);
  }
  
}
